import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.net.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ludum_dare_46_client extends PApplet {



ArrayList<Player> players = new ArrayList<Player>();
Client client;
float ID = -1;
boolean joined = false;
boolean Lmouse = false;
int selectedPlayer;
public void setup(){
  //settings
  
  colorMode(RGB);
  
  frameRate(24);
  
  // write connecting on the screen
  
  background(0);
  textAlign(CENTER,CENTER);
  stroke(255);
  textSize(100);
  text("connecting",width/2,height/2);
}

public void draw(){
  if(!joined){
    connect();
    joined = true;
  }
  interwebs();
  // update and clear the cache
  updateMyself();
  client.clear();
  
  
  //visuals
  
  if(ID == -1){background(0);}
  else{
    visuals();
  }
}
public void connect(){
  client = new Client(this,"203.208.118.131",5204);
  client.write("connecting_send_ID;");
  boolean go = false;
  while(!go){
    if(client.available() > 0){
      String Fullread = client.readString();
      for(String read : Fullread.split(";")){
        String[] split = read.split(" ");
        if(split[0].equals("connecting_ID")){

          //first connection complete

          println("I got my ID:",split[1]);
          ID = PApplet.parseFloat(split[1]);
          client.write("request_static_game_data;");
        }
        if(split[0].equals("sending_static_game_data")){
          println("i got the game data");
          client.write("request_thing");
        }
        if(split[0].equals("sending_thing")){
          println("i got the thing");
          go = true;
        }
      }
    }
    //println("connecting");
  }
}
public void generalise(String input){
  input.replace("'","");
  String tokens = "., ";
  String[] words = splitTokens(input,tokens);
  ArrayList<String> generalised = new ArrayList<String>();
  
  for(int num = 0; num < words.length; num++){
    //println(num);
    for(String[][] G : generalise){
      for(int n = 1; n < G.length; n++){
        String[] P = G[n];
        boolean same = true;
        if(P.length+num<words.length+1){
          for(int i = 0; i < P.length; i++){
            if(!same(words[i+num],P[i])){
              same = false;
            }
          }
          if(same){
            generalised.add(G[0][0]);
            for(int i = 0; i < P.length; i++){
              words[num] = "";
            }
            //println(G[0][0]);
          }
        }
      }
    }
  }
  for(String S : generalised){
    println(S);
  }
}

public boolean same(String A, String B){
  if(A.length() != B.length()){return false;}
for(int i = 0; i < A.length(); i++){if(A.charAt(i) != B.charAt(i)){return false;}}
  return true;
}
boolean left,right,up,down;
String text = "";
int[] illegal = {16,20,9,17,524,18,17,37,38,40,39,16
};

public void keyPressed(){
  //println(keyCode);
  if(keyCode == 27){client.write("end_of_session "+ID+";");}
  if(keyCode == 10){
    text = join(text.split(" "),",");
    say(text);
    text = "";
  }
  else if(keyCode == 8){
    if(text.length() != 0){text = text.substring(0,text.length()-1);}
  }
  else{
    boolean yes = true;
    for(int i : illegal){
      if(keyCode == i){yes = false;}
    }
    if(yes){text += key;}
  }
}
public void keyReleased(){
}



public void mousePressed(){
  if(mouseButton == LEFT){
    Lmouse = true;
  }
  
}

public void mouseReleased(){
  if(mouseButton == LEFT){
    Lmouse = false;
  }
}  

public void say(String text){
  client.write("saying "+ID+" "+text+";");
}
String[][][] generalise = {{{"not allowed"},{"what","is","your","phrase"},{"what","is","your","word"}}};
String[][][] words = {{{"U.F.O"},{"ufo"},{"UFO"},{"u.f.o"}},{{"thankyou","very","much"},{"thankyou","so","much"}}};
public void interwebs(){
  if(client.available()>0){
    String fullRead = client.readString();
    for(String read : fullRead.split(";")){
      String[] split = read.split(" ");
      if(split[0].equals("remove_player")){
        for(Player P : players){if(P.ID == PApplet.parseFloat(split[1])){players.remove(P);break;}}
      }
      if(split[0].equals("end")){client.stop();exit();}
      if(split[0].equals("sending_static player data")){
        if(PApplet.parseFloat(split[1]) == ID){
          // information about a yourself that doesnt change is being received
          println(read);
        }
        else{
          for(Player P : players){
            if(P.ID == PApplet.parseFloat(split[1])){
              //information about another player that doesnt change is being received
              println(read);
            }
          }
        }
      }
      if(split[0].equals("said")){
        String[] add = {split[1],join(split[2].split(",")," ")};
        chat.add(add);
      }
      if(split[0].equals("update_stats")){
        if(PApplet.parseFloat(split[1]) == ID){
          //information about yourself is being received
          
        }
        else{
          boolean inThere = false;
          for(Player P : players){
            if(P.ID == PApplet.parseFloat(split[1])){
              inThere = true;
              //information about someone else is being received
            }
          }
          if(!inThere){
            // a new player has been detected
            client.write("request_static_player_data"+split[1]+";");
            players.add(new Player(PApplet.parseFloat(split[1])));
          }
        }
      }
    }
  }
}
public void updateMyself(){
  client.write("update_stats "+ID+" stats"+";");
}

class Player{
  float ID;
  Player(float id){
    ID = id;
  }
}
ArrayList<String[]> chat = new ArrayList<String[]>();
public void visuals(){
  background(255);
  float ts = 25;
  drawChat(chat,100,100,width/2,height-300,ts*2);
  fill(0);
  rect(100-(ts*2),height-150+ts,(width/2)+(ts*4),100);
  textSize(60);
  fill(255);
  text(text,100-(ts*2)+10,height-150+ts+70);
}

public void drawChat(ArrayList<String[]> chat, float chatX, float chatY, float chatW, float chatH, float textSize){
  fill(0);
  rect(chatX-textSize,chatY-textSize,chatW+(textSize*2),chatH+(textSize*2));
  float Y = height;
  textAlign(LEFT);
  for(int y = chat.size()-1; y>=0;y--){
    if(Y >= chatY){
      String string = chat.get(y)[0]+": "+chat.get(y)[1];
      Y = (chatY+chatH)-((chat.size()-1-y)*textSize*2);
      textSize(textSize);
      fill(255);
      text(string,chatX,Y);
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ludum_dare_46_client" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
