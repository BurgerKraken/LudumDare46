import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.net.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ludum_dare_46_client extends PApplet {



ArrayList<Player> players = new ArrayList<Player>();
Client client;
Player me;
float ID = -1;
boolean joined = false;
boolean Lmouse = false;
int selectedPlayer = -1;
public void setup(){
  //settings
  PImage icon = loadImage("icon.png");
  surface.setIcon(icon);
  colorMode(RGB);
  
  frameRate(24);
  
  //pictures and music
  background = loadImage("background.png");
  background.resize(width,height);
  // write connecting on the screen
  
  background(0);
  textAlign(CENTER,CENTER);
  stroke(255);
  textSize(100);
  text("connecting",width/2,height/2);
}

public void draw(){
  if(!joined){
    connect();
    joined = true;
  }
  interwebs();
  // update and clear the cache
  updateMyself();
  client.clear();
  
  
  //visuals
  
  if(ID == -1){background(0);}
  else{
    visuals();
  }
}
public void connect(){
  client = new Client(this,"203.208.118.131",5204);
  client.write("connecting_send_ID;");
  boolean go = false;
  while(!go){
    if(client.available() > 0){
      String Fullread = client.readString();
      for(String read : Fullread.split(";")){
        String[] split = read.split(" ");
        if(split[0].equals("connecting_ID")){

          //first connection complete

          println("I got my ID:",split[1]);
          ID = PApplet.parseFloat(split[1]);
          me = new Player(PApplet.parseFloat(split[1]));
          client.write("request_static_game_data;");
        }
        if(split[0].equals("sending_static_game_data")){
          println("i got the game data");
          client.write("request_static_player_data "+ID);
        }
        if(split[0].equals("sending_static_player_data") && PApplet.parseFloat(split[1]) == ID){
          println("i got my data");
          me.name = split[2];
          go = true;
        }
      }
    }
    //println("connecting");
  }
}
public void generalise(String input){
  input.replace("'","");
  String tokens = "., ";
  String[] words = splitTokens(input,tokens);
  ArrayList<String> generalised = new ArrayList<String>();
  
  for(int num = 0; num < words.length; num++){
    //println(num);
    for(String[][] G : generalise){
      for(int n = 1; n < G.length; n++){
        String[] P = G[n];
        boolean same = true;
        if(P.length+num<words.length+1){
          for(int i = 0; i < P.length; i++){
            if(!same(words[i+num],P[i])){
              same = false;
            }
          }
          if(same){
            generalised.add(G[0][0]);
            for(int i = 0; i < P.length; i++){
              words[num] = "";
            }
            //println(G[0][0]);
          }
        }
      }
    }
  }
  for(String S : generalised){
    println(S);
  }
}

public boolean same(String A, String B){
  if(A.length() != B.length()){return false;}
for(int i = 0; i < A.length(); i++){if(A.charAt(i) != B.charAt(i)){return false;}}
  return true;
}
boolean left,right,up,down;
String text = "";
int[] illegal = {16,20,9,17,524,18,17,37,38,40,39,16
};

public void keyPressed(){
  //println(keyCode);
  if(keyCode == 9){
    if(players.size()!= 0){
      block(selectedPlayer);
    }
  }
  if(keyCode == 27){
    client.write("end_of_session "+ID+";");
    boolean done = false;
    while(!done){
      for(int i = 0; i < 100000000; i++){}
      if(client.available() >0){
        String readFull = client.readString();
        for(String read : readFull.split(";")){
          if(read.equals("remove_player "+str(ID))){
            done = true;
          }
        }
      }
      else{
        client.write("end_of_session "+ID+";");
      }
    }
    exit();
  }
  if(selectedPlayer != -1){
    if(keyCode == 10){
      text = join(text.split(" "),",");
      if(text != null && text!= ""){
        say(text);
      }
      text = "";
    }
    else if(keyCode == 8){
      if(text.length() != 0){text = text.substring(0,text.length()-1);}
    }
    else{
      boolean yes = true;
      for(int i : illegal){
        if(keyCode == i){yes = false;}
      }
      if(yes){textSize(ts*2);if(textWidth(text+key) < 820-(ts*1.1f))text += key;}
    }
  }
}
public void keyReleased(){
}



public void mousePressed(){
  if(mouseButton == LEFT){
    if(mouseX > 312 && mouseX < 512){
      if(mouseY>147 && mouseY < 930){
        if(map(mouseY,147,730,0,2)-floor(map(mouseY,147,730,0,2))<.68f){
          selectedPlayer = floor(map(mouseY,147,730,0,2));
        }
      }
    }
  }
  
}

public void mouseReleased(){
  if(mouseButton == LEFT){
    Lmouse = false;
  }
}  

public void say(String text){
  client.write("saying "+ID+" "+players.get(selectedPlayer).ID+" "+"."+text+"."+";");
}
String[][][] generalise = {{{"not allowed"},{"what","is","your","phrase"},{"what","is","your","word"}}};
String[][][] words = {{{"U.F.O"},{"ufo"},{"UFO"},{"u.f.o"}},{{"thankyou","very","much"},{"thankyou","so","much"}}};
public void interwebs(){
  if(client.available()>0){
    String fullRead = client.readString();
    for(String read : fullRead.split(";")){
      String[] split = read.split(" ");
      interpret(read,split);
    }
  }
}

public void interpret(String read, String[] split){
  if(split[0].equals("remove_player")){
    for(Player P : players){
      if(P.ID == PApplet.parseFloat(split[1])){
        me.friends--;
        players.remove(P);
        break;
      }
    }
  }
  if(split[0].equals("end")){client.stop();exit();}
  if(split[0].equals("sending_static_player_data")){
    if(PApplet.parseFloat(split[1]) == ID){
      // information about a yourself that doesnt change is being received
    }
    else{
      for(Player P : players){
        if(P.ID == PApplet.parseFloat(split[1])){
          //information about another player that doesnt change is being received
          P.name = split[2];
        }
      }
    }
  }
  if(split[0].equals("said")){
    if(PApplet.parseFloat(split[1]) == ID){
      for(int n = 0; n < players.size(); n++){
        String[] add = {me.name,join(split[3].replace(".","").split(",")," ")};
        if(players.get(n).ID == PApplet.parseFloat(split[2])){
          chats.get(n).add(add);
        }
      }
    }
    else{
      for(int n = 0; n < players.size(); n++){
        if(players.get(n).ID == PApplet.parseFloat(split[1])){
          if(ID == PApplet.parseFloat(split[2]));{
            if(players.get(n).name != null){
              String[] add = {players.get(n).name,join(split[3].split(",")," ")};
              chats.get(n).add(add);
            }
          }
        }
      }
    }
  }
  if(split[0].equals("block")){
    //println(split[1],"blocked",split[2]);
    if(PApplet.parseFloat(split[2]) == ID){
      for(int n = 0; n < players.size(); n++){
        if(players.get(n).ID == PApplet.parseFloat(split[1])){
          block(n);
        }
      }
    }
  }
  if(split[0].equals("update_stats")){
    if(PApplet.parseFloat(split[1]) == ID){
      //information about yourself is being received
      
    }
    else{
      //boolean inThere = false;
      for(Player P : players){
        if(P.ID == PApplet.parseFloat(split[1])){
          //inThere = true;
          //information about someone else is being received
        }
      }
      //if(!inThere && float(split[1]) != ID){
        //if(me.friends < 3){
          // a new player has been detected
        //}
      //}
    }
  }
  if(split[0].equals("pair_up")){
    println("pair up:",read);
    if(PApplet.parseFloat(split[1]) == ID){
      float id = PApplet.parseFloat(split[2]);
      boolean go = true;
      for(Player P : players){if(P.ID == id){go = false;}}
      if(go){
        client.write("request_static_player_data "+id+";");
        players.add(new Player(id));
        println("now i have",players.size(),"friends");
        chats.add(new ArrayList<String[]>());
        me.friends++;
        selectedPlayer = 0;
      }
    }
    if(PApplet.parseFloat(split[2]) == ID){
      float id = PApplet.parseFloat(split[1]);
      boolean go = true;
      for(Player P : players){if(P.ID == id){go = false;}}
      if(go){
        client.write("request_static_player_data "+id+";");
        players.add(new Player(id));
        println("now i have",players.size(),"friends");
        chats.add(new ArrayList<String[]>());
        me.friends++;
        selectedPlayer = 0;
      }
    }
  }
}
public void updateMyself(){
  client.write("update_stats "+ID+" stats"+";");
  if(me.friends<3){client.write("request_friends "+ID+";");}
}

class Player{
  float ID;
  String name;
  int friends = 0;
  FloatList blocked;
  Player(float id){
    ID = id;
    blocked = new FloatList();
  }
}

public void block(int which){
  text = "";
  Player P = players.get(which);
  chats.remove(chats.get(which));
  me.blocked.append(P.ID);
  me.friends--;
  players.remove(which);
  if(players.size()!= 0){selectedPlayer = 0;}
  else{selectedPlayer = -1;}
  client.write("block "+ID+" "+P.ID+";");
}
ArrayList<ArrayList<String[]>> chats = new ArrayList<ArrayList<String[]>>();
PImage background;
float ts = 12.5f;

public void visuals(){
  background(background);
  if(selectedPlayer != -1){
  ArrayList<String[]> chat = chats.get(selectedPlayer);
  drawChat(chat,599,157,805,660,ts*2);
  fill(0,0,0,100);
  rect(565,902,820,70);
  textSize(ts*2);
  fill(0);
  text(text,565+ts,902+(35+ts)*0.9f);
    for(int p = 0; p < players.size(); p++){
      rect(312,map(p,0,2,147,720),200,200);
      fill(0);
      if(players.get(p).name != null){
        textAlign(CENTER,BOTTOM);
        text(players.get(p).name,412,map(p,0,2,392,965));
      }
    }
  }
}

public void drawChat(ArrayList<String[]> chat, float chatX, float chatY, float chatW, float chatH, float textSize){
  fill(0,0,0,100);
  rect(chatX-textSize,chatY-textSize,chatW+(textSize*2),chatH+(textSize*2));
  float Y = height;
  textAlign(LEFT);
  for(int y = chat.size()-1; y>=0;y--){
    if(Y >= chatY){
      String string = chat.get(y)[0]+": "+chat.get(y)[1];
      Y = (chatY+chatH)-((chat.size()-1-y)*textSize*1.3f);
      textSize(textSize);
      fill(0);
      text(string,chatX,Y);
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ludum_dare_46_client" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
